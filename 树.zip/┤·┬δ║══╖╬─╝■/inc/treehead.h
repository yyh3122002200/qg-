//
// Created by eke_l on 2021/4/21.
//

#ifndef BINARYSORTTREE_BINARY_SORT_TREE_H
#define BINARYSORTTREE_BINARY_SORT_TREE_H

#define true 1
#define false 0
#define succeed 1
#define failed 0
#define Status int

typedef int ElemType;

typedef struct Node {
    ElemType value;
    struct Node* left, * right;
}Node, * NodePtr;




Status BST_init(NodePtr L);
Status BST_insert(NodePtr L, ElemType);
Status BST_delete(NodePtr L, ElemType);
Status BST_search(NodePtr L, ElemType);
Status BST_preorderR(NodePtr L);
Status BST_inorderR(NodePtr L);
Status BST_postorderR(NodePtr L);
Status BST_levelOrder(NodePtr L);

Status BST_preorderS(NodePtr L, ElemType e);


typedef struct node
{
    ElemType value;                   //������ָ��
    struct node* next;            //ָ��ǰ������һ���
} LNode, * LNodeList;

typedef struct Lqueue
{
    LNode* front;                   //��ͷ
    LNode* rear;                    //��β
    int length;            //���г���
} LQueue;


void InitLQueue(LQueue *Q);
Status EnLQueue(LQueue* Q, ElemType);
Status DeLQueue(LQueue* Q);



#endif //BINARYSORTTREE_BINARY_SORT_TREE_H