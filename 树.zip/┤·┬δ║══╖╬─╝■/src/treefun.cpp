#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"treehead.h"


Status BST_init(NodePtr L) {
	int num = 0;
	char judge = '0';
	

	printf("���������ֵ��");
	scanf_s("%d", &num);
	judge = getchar();
	while (judge != '\n') {
		fflush(stdin);
		printf("�밴Ҫ��������������:");
		scanf_s("%d", &num);
		judge = getchar();
	}
	L->value = num;
	L->left = NULL;
	L->right = NULL;
	return succeed;
}



Status BST_insert(NodePtr L, ElemType e) {
	if (L == NULL)
	{
		return failed;
	}

	NodePtr q = (NodePtr)malloc(sizeof(Node));//�����½ڵ�

	char judge = '0';

	printf("������ڵ���ֵ��");
	scanf_s("%d", &e);
	judge = getchar();
	while (judge != '\n') {
		fflush(stdin);
		printf("�밴Ҫ��������������:");
		scanf_s("%d", &e);
		judge = getchar();
	}

	q->value = e;
	q->left = NULL;
	q->right = NULL;
	NodePtr p = L;
	if (p == NULL)
	{
		L = q;
		return succeed;
	}

	NodePtr k = NULL;

	while (p != NULL)
	{
		k = p;
		if (p->value == e)
		{
			return failed;
		}
		if (p->value > e)
		{
			p = p->left;
		}
		else
		{
			p = p->right;
		}
	}

	if ((k->value) > e)
	{
		k->left = q;
	}
	else
	{
		k->right = q;
	}//�жϽ��λ������������������
	return succeed;

}

Status BST_delete(NodePtr L, ElemType e) {
	
	return succeed;
}

Status BST_search(NodePtr L, ElemType e) {
	if (L == NULL)
	{
		return failed;
	}

	char judge = '0';

	printf("�����������ֵ��");
	printf("���޷����������ʧ��\n");
	scanf_s("%d", &e);
	judge = getchar();
	while (judge != '\n') {
		fflush(stdin);
		printf("�밴Ҫ��������������:");
		scanf_s("%d", &e);
		judge = getchar();
	}

	if (e == L->value) {
		printf("���ҳɹ�����������\n");
	}
	BST_preorderS(L->left,e);
	BST_preorderS(L->right,e);
	return succeed;
}


Status BST_preorderS(NodePtr L, ElemType e) {
	if (L == NULL)
	{
		return failed;
	}
	if (e == L->value) {
		printf("���ҳɹ�����������\n");
	}

	BST_preorderS(L->left,e);
	BST_preorderS(L->right,e);
	return succeed;
}



Status BST_preorderR(NodePtr L) {
	if (L == NULL)
	{
		return failed;
	}
	printf("%d  ", L->value);
	BST_preorderR(L->left);
	BST_preorderR(L->right);
	return succeed;
}


Status BST_inorderR(NodePtr L) {
	if (L == NULL)
	{
		return failed;
	}
	BST_inorderR(L->left);
	printf("%d  ", L->value);
	BST_inorderR(L->right);
	return succeed;
}



Status BST_postorderR(NodePtr L) {
	if (L == NULL)
	{
		return failed;
	}
	BST_postorderR(L->left);
	BST_postorderR(L->right);
	printf("%d  ", L->value);
	return succeed;
}

Status BST_levelOrder(NodePtr L) {

	return succeed;
}


void InitLQueue(LQueue* Q) {
	//Q->front = Q->rear = (LQueue)malloc(sizeof(LQueue));
	Q->front = NULL;
	Q->rear = NULL;
	Q->length = 0;
	return;
}

Status EnLQueue(LQueue* Q, ElemType e) {
	LNodeList p = (LNodeList)malloc(sizeof(LNodeList));
	p->value = e;
	p->next = NULL;
	if (Q->front == NULL && Q->rear == NULL) {
		Q->front = Q->rear = p;
	}
	else {
		Q->rear->next = p;
		Q->rear = p;
	}
	Q->length++;
	return succeed;
}

Status DeLQueue(LQueue* Q) {
	if (Q->front->next == NULL) {
		free(Q->front);
		Q->front = Q->rear = (LNodeList)malloc(sizeof(LNodeList));
	}
	else {
		LNodeList p = Q->front->next;
		free(Q->front);
		Q->front = p;
	}
	return succeed;
}