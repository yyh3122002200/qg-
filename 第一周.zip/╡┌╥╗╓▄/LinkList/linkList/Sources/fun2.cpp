#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>

#include<string.h>

#include<stdlib.h>

#include"head2.h"

Status InitList_DuL(DuLinkedList* L) {
	*L = (DuLinkedList)malloc(sizeof(DuLNode));
	if (!(*L))
		return ERROR;
	(*L)->prior = NULL;
	(*L)->next = NULL;
	(*L)->data = 0;
	return SUCCESS;
}


Status built(DuLinkedList* L) {
	DuLinkedList p;
	p = (DuLinkedList)malloc(sizeof(DuLNode));
	if (!(p))
		printf("�ڴ�������");
	DuLinkedList q;
	p = *L;
	int i = 0;
	printf("������Ҫ������ٸ�Ԫ�أ�");
	scanf_s("%d", &i);
	for (int j = 0; j < i; j++) {
		q = (DuLinkedList)malloc(sizeof(DuLNode));
		if (!q)
			printf("�ڴ�������");
		p->next = q;
		int n = 0;
		printf("������Ԫ�ص�ֵ��");
		scanf_s("%d", &n);
		q->data = n;
		q->prior = q;
		q->next = NULL;
		p = q;
	}
	return SUCCESS;
}

void DestroyList_DuL(DuLinkedList* L) {
	DuLinkedList p;
	p = (DuLinkedList)malloc(sizeof(DuLNode));
	if (!p)
		printf("�ڴ�������");
	while ((*L)!=NULL) {
		p = *L;
		*L = (*L)->next;
		free(p);
	}
}

Status InsertBeforeList_DuL(DuLNode* p, DuLNode* q) {
	if (p == NULL)
		return ERROR;
	q = (DuLinkedList)malloc(sizeof(DuLNode));
	DuLinkedList k = p;
	int j = 0;
	printf("������p��λ�ã�");
	int sp = 0;
	scanf_s("%d", &sp);
	printf("������������ֵ:");
	scanf_s("%d", &q->data);
	for (int i = 0; i < sp-1; i++) {
		k = k->next;
	}
	if (k->next != NULL) {
		k->next->prior = q;
		q->next = k->next;
		k->next = q;
		k->prior = k;
	}
	else
	printf("�޷����룡");
	return SUCCESS;
}
Status InsertAfterList_DuL(DuLNode* p, DuLNode* q)
{
	if (p == NULL)
		return ERROR;
	q = (DuLinkedList)malloc(sizeof(DuLNode));
	DuLinkedList k = p;
	int j = 0;
	printf("������p��λ�ã�");
	int sp = 0;
	scanf_s("%d", &sp);
	printf("������������ֵ:");
	scanf_s("%d", &q->data);
	for (int i = 1; i < sp ; i++) {
		k = k->next;
	}
	if (k->next != NULL) {
		k->next->prior = q;
		q->next = k->next;
		k->next = q;
		k->prior = k;
	}
	else
		printf("�޷����룡");
	return SUCCESS;
}


Status DeleteList_DuL(DuLNode* p, ElemType* e) {
	DuLinkedList k;
	k = (DuLinkedList)malloc(sizeof(DuLNode));
	k=p;
	printf("������ɾ����λ�ã�");
	int sp = 0;
	scanf_s("%d", &sp);
	for (int i = 0; i < sp-1; i++) {
		k = k->next;
	}
	DuLinkedList q;
	q = (DuLinkedList)malloc(sizeof(DuLNode));
	q = k->next;
	if (k != NULL) {
		*e = q->data;
		k->next = q->next;
		q->next->prior = k;
		free(q);
	}
	else
		printf("�޷�ɾ����");

	return SUCCESS;
}

void TraverseList_DuL(DuLinkedList L) {
	DuLNode* p = L->next;
	while (p != NULL)
	{
		printf("%d->", p->data);
		p = p->next;
	}
	printf("\n");
}


