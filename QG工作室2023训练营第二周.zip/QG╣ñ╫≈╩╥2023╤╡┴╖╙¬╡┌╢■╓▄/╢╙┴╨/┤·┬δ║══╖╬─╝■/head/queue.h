#ifndef LQUEUE_H_INCLUDED
#define LQUEUE_H_INCLUDED
#include<stdlib.h>
typedef enum Status
{
    ERROR = 0,
    SUCCESS = 1
} Status;


typedef struct node
{
    void *data;                   //������ָ��
    struct node *next;            //ָ��ǰ������һ���
} Node, *NodeList;

typedef struct Lqueue
{
    Node *front;                   //��ͷ
    Node *rear;                    //��β
    int length;            //���г���
} LQueue;

					
void InitLQueue(LQueue *Q);
void DestoryLQueue(LQueue *Q);
Status IsEmptyLQueue(const LQueue *Q);
Status GetHeadLQueue(LQueue *Q, void *e,int a);
int LengthLQueue(LQueue *Q);
Status EnLQueue(LQueue *Q, void *data);
Status DeLQueue(LQueue *Q);
Status TraverseLQueue(const LQueue *Q, int a);
void LPrint(void *q,int a);

#endif
