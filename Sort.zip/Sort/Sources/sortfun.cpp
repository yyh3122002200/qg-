#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
#include<time.h>
#include<stdlib.h>
#include<windows.h>
#include"sort.h"


void insertSort(int* a, int n) {
	for (int i = 1; i < n; i++) {
		int itemp = a[i];     //���ò���ֵ
		int ipos = i - 1;
		while ((ipos >= 0) && (itemp < a[ipos])) {    //Ѱ�Ҳ���ֵλ��
			a[ipos + 1] = a[ipos];                   //����
			ipos--;
		}
		a[ipos + 1] = itemp;        //ͬ
	}
	return;
}


void MergeArray(int* a, int begin, int mid, int end, int* temp) {
	int i = begin;
	int j = mid + 1;
	int k = begin;
	while ((i <= mid) && (j <= end))
		if (a[i] <= a[j])
		{
			temp[k] = a[i];
			i++;
			k++;
		}
		else
		{
			temp[k] = a[j];
			j++; 
			k++;
		}
	while (i <= mid) {
		temp[k++] = a[i++];
	}
	while (j <= end) {
		temp[k++] = a[j++];
	}
}


void MergeSort(int* a , int begin, int end, int* temp ) {
	int mid=0;
	int t[20];
	if (begin == end)
		temp[begin] = a[end];
	else
	{
		mid = (begin + end) / 2;
		MergeSort(a, mid, begin, t);
		MergeSort(a, end, mid + 1, t);
		MergeArray(t, end, begin, mid, temp);
	}
}

void QuickSort_Recursion(int* a, int begin, int end) {
	if (begin >= end) {
		return;
	}
	int left = begin;
	int right = end;
	int key = left;       //����Ϊkey
	while (left < right) {
		while (left < right && a[right] >= a[key]) {//����С
			right--;
		}
		while (left < right && a[right] <= a[key]) {//�Ҵ�
			left++;
		}
		if (left < right) {       //��ʱ����
			Swap(&a[left], &a[right]);     //���뺯��
		}
	}
	int meet = left;         //������
	Swap(&a[key], &a[meet]);
	QuickSort_Recursion(a, begin, meet - 1);   //��������
	QuickSort_Recursion(a, meet + 1, end);     //��
}


void CountSort(int* a, int size) {
	if (size < 1) {
		return;
	}
	int max = a[0];           //�������
	for (int i = 1; i < size; i++) {
		if (a[i] > max) {
			max = a[i];         //����Ѱ�������
		}
	}
	int count[200000];          //��ת����
	int count2[200000];
	for (int j = 0; j < size; j++) {   //�����ֵԪ������
		count[a[j]]++;
	}
	for (int k = 1; k < size; k++) {
		count[k] += count[k - 1];       //�ۼӣ�С�ڵ���i��Ԫ�ظ���
	}
	for (int g = 0; g < size; g++) {    //��ȷ˳�򷵻�
		count2[count[a[g]] - 1] = a[g];
		count[a[g]]--;
	}
}

void RadixCountSort(int* a, int size){
	int* b[10];    //�ֱ�Ϊ0-9�����пռ�
	for (int i = 0; i < 10; i++)
	{
		b[i] = (int*)malloc(sizeof(int) * (size + 1));
		b[i][0] = 0;    //indexΪ0����¼�������ݵĸ���
	}

	for (int i = 0; i < 10; i++)    //�Ӹ�λ��ʼ��31λ
	{
		for (int j = 0; j < size; j++)    //�������
		{
			int num = GetNumInPos(a[i], i);
			int index = ++b[num][0];
			b[num][index] = a[i];
		}

		for (int i = 0, j = 0; i < 10; i++)    //�ռ�
		{
			for (int k = 1; k <= b[i][0]; k++)
				a[j++] = b[i][k];
			b[i][0] = 0;    //��λ
		}
	}
}

void Swap(int* a, int* b) {   //����
	int k = *a;
	*a = *b;
	*b = k;
}

int GetNumInPos(int num, int a)
{
	int temp = 1;
	for (int i = 0; i < a - 1; i++)
		temp *= 10;

	return ((num / temp) % 10);
}

void show() {
	printf("********************\n");
	printf("**1.����          **\n");
	printf("**2.����          **\n");
	printf("**3.����          **\n");
	printf("**4.����          **\n");
	printf("**5.����          **\n");
	printf("**0.�˳�����      **\n");
	printf("********************\n");
}

void num1() {
	int t[10000] = { 0 };
	int t1[10000] = { 0 };
	for (int i = 0; i < 10000; i++) {
		t[i] = rand() % 100;     //�����
	}
	show();
	int num = 0;
	int length;
	int i = 0;
	char judge = '0';
	do {
		printf("������Ҫִ�еĳ����ţ�");
		scanf_s("%d", &num);
		judge = getchar();
		while (judge != '\n') {
			fflush(stdin);
			printf("�밴Ҫ��������������:");
			scanf_s("%d", &num);
			judge = getchar();
		}
		int f = clock();
		switch (num)
		{
		case 1:
			insertSort(t, 10000);
			break;
		case 2:
			MergeSort(t, 0, 9999, t1);
			break;
		case 3:
			QuickSort_Recursion(t, 0, 9999);
			break;
		case 4:
			CountSort(t, 10000);
			break;
		case 5:
			RadixCountSort(t, 10000);
			break;
		case 0:
			printf("���˳�");
		default:
			break;
		}
		int c = clock() - f;
		printf("%dms\n", c);
	} while (num);
}

void num2() {
	int t[50000] = { 0 };
	int t1[50000] = { 0 };
	for (int i = 0; i < 50000; i++) {
		t[i] = rand() % 100;     //�����
	}
	show();
	int num = 0;
	int length;
	int i = 0;
	char judge = '0';
	do {
		printf("������Ҫִ�еĳ����ţ�");
		scanf_s("%d", &num);
		judge = getchar();
		while (judge != '\n') {
			fflush(stdin);
			printf("�밴Ҫ��������������:");
			scanf_s("%d", &num);
			judge = getchar();
		}
		int f = clock();
		switch (num)
		{
		case 1:
			insertSort(t, 50000);
			break;
		case 2:
			MergeSort(t, 0, 49999, t1);
			break;
		case 3:
			QuickSort_Recursion(t, 0, 49999);
			break;
		case 4:
			CountSort(t, 50000);
			break;
		case 5:
			RadixCountSort(t, 50000);
			break;
		case 0:
			printf("���˳�");
		default:
			break;
		}
		int c = clock() - f;
		printf("%dms\n", c);
	} while (num);
}

void num3() {
	int t[200000] = { 0 };
	int t1[200000] = { 0 };
	for (int i = 0; i < 200000; i++) {
		t[i] = rand() % 100;     //�����
	}
	show();
	int num = 0;
	int length;
	int i = 0;
	char judge = '0';
	do {
		printf("������Ҫִ�еĳ����ţ�");
		scanf_s("%d", &num);
		judge = getchar();
		while (judge != '\n') {
			fflush(stdin);
			printf("�밴Ҫ��������������:");
			scanf_s("%d", &num);
			judge = getchar();
		}
		int f = clock();
		switch (num)
		{
		case 1:
			insertSort(t, 200000);
			break;
		case 2:
			MergeSort(t, 0, 199999, t1);
			break;
		case 3:
			QuickSort_Recursion(t, 0, 199999);
			break;
		case 4:
			CountSort(t, 199999);
			break;
		case 5:
			RadixCountSort(t, 199999);
			break;
		case 0:
			printf("���˳�");
		default:
			break;
		}
		int c = clock() - f;
		printf("%dms\n", c);
	} while (num);
}

void num4() {
	int t[100] = { 0 };
	int t1[100] = { 0 };
	for (int i = 0; i < 100; i++) {
		t[i] = rand() % 1000;     //�����
	}
	show();
	int num = 0;
	int length;
	int i = 0;
	char judge = '0';
	do {
		printf("������Ҫִ�еĳ����ţ�");
		scanf_s("%d", &num);
		judge = getchar();
		while (judge != '\n') {
			fflush(stdin);
			printf("�밴Ҫ��������������:");
			scanf_s("%d", &num);
			judge = getchar();
		}
		int f = clock();
		switch (num)
		{
		case 1:
			insertSort(t, 1000);
			break;
		case 2:
			MergeSort(t, 0, 999, t1);
			break;
		case 3:
			QuickSort_Recursion(t, 0, 999);
			break;
		case 4:
			CountSort(t, 1000);
			break;
		case 5:
			RadixCountSort(t, 1000);
			break;
		case 0:
			printf("���˳�");
		default:
			break;
		}
		int c = clock() - f;
		printf("%dms\n", c*100000);
	} while (num);
}

void num5() {
	return;
}
