#include"reg51.h"
sbit LED0=P2^0;
sbit buzzer=P1^0;
unsigned char s[]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
unsigned char num=0;

void delay(unsigned int n)
{
	unsigned int i=0,j=0;
	for(i=0;i<n;i++){
		for(j=0;j<1000;j++);
	}
}

	

void led()
{
	int i=0;
	for(i=0;i<8;i++){
		P2=~(0x01<<i);
		delay(50);
		}
}

void led1()
{
	int i=0;
	for(i=0;i<8;i++){
		P1=(0x01<<i);
		delay(50);
		}
}

 void initti()
 {
 	TMOD=0x06;
	TH0= 256-1;
	TL0= 256-1;
	ET0=1;
	EA=1;
	TR0=1;
}

void diaplay()
{	
	P2=s[num];
	if(num==10)
	{
	num=0;
	} 
}
	
void isr() interrupt 1
{
	num++;
	}

 void main(){
 	initti();
 	while(1){
	 ////ѡ��1
	//	buzzer=0;
	//	led();
	//	led1() ;
	//	buzzer=1;
	//	delay(10);
	///ѡ��2
		diaplay();
		}

 }